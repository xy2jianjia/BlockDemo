//
//  SceneDelegate.h
//  DyldDemo
//
//  Created by monan on 2021/7/13.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

