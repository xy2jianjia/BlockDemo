//
//  AppDelegate.h
//  DyldDemo
//
//  Created by monan on 2021/7/13.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

