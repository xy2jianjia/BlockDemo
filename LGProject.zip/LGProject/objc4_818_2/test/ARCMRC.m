//
//  ARCMRC.m
//

#import "ARCMRC.h"

@implementation ARCMRC

@synthesize dataSource;

@end
