//
//  main.m
//  QLObjcTest
//
//  Created by monan on 2021/6/28.
//  Copyright © 2021 xy2. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import "QLPerson.h"
#import "QLPerson+NB1.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        
//        // class_data_bits_t
//        QLPerson *person = [QLPerson alloc];
////
////        NSLog(@"%@",person);
//
//        [person cat_test1];
//        [person cat_test2];
//        [QLPerson cat_test];
        
        NSObject *obj = [NSObject alloc];
        void (^ qlBlock)(void) = ^{
            NSLog(@"---%@---",obj);
        };
        qlBlock();
        
        
//        int aa = 100;
//        void(^  weakBlock)(void) = ^{
//            NSLog(@"%d",aa);
//        };
//        void (^__weak strongBlock  )(void) = weakBlock;
//
//        strongBlock();
        
    }
    return 0;
}


