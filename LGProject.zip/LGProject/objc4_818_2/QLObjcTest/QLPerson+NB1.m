//
//  QLPerson+NB1.m
//  QLObjcTest
//
//  Created by monan on 2021/8/10.
//  Copyright © 2021 xy2. All rights reserved.
//

#import "QLPerson+NB1.h"

@implementation QLPerson (NB1)

+(void)load {
    NSLog(@"%s",__func__);
}
- (void) cat_test1{
    NSLog(@"%s",__func__);
}
- (void) cat_test2{
    NSLog(@"%s",__func__);
}

+ (void) cat_test{
    NSLog(@"%s",__func__);
}

@end
