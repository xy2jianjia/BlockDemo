//
//  QLPerson+NB1.h
//  QLObjcTest
//
//  Created by monan on 2021/8/10.
//  Copyright © 2021 xy2. All rights reserved.
//

#import "QLPerson.h"

NS_ASSUME_NONNULL_BEGIN

@interface QLPerson (NB1)<NSObject>

@property (nonatomic,copy) NSString *cat_name;
@property (nonatomic,assign) int cat_age;


- (void) cat_test1;
- (void) cat_test2;

+ (void) cat_test;


@end

NS_ASSUME_NONNULL_END
