//
//  QLPerson.h
//  QLTest
//
//  Created by monan on 2021/6/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//@protocol QLDelegate <NSObject>
//
//- (void) runrun;
//
//@end

@interface QLPerson : NSObject{
    NSString *fullName;
}

@property (nonatomic,copy) NSString *nickName;
@property (nonatomic,assign) NSInteger age;
//@property (nonatomic,weak) id<QLDelegate> aObj;

- (void)test1;
+ (void)test2;


@end

NS_ASSUME_NONNULL_END
