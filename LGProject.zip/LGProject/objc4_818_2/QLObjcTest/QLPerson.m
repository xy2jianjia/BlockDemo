//
//  QLPerson.m
//  QLTest
//
//  Created by monan on 2021/6/7.
//

#import "QLPerson.h"

@implementation QLPerson

//+(void)load {
//    NSLog(@"%s",__func__);
//}

- (void)test1{
    NSLog(@"%s",__func__);
}
+ (void)test2{
    NSLog(@"%s",__func__);
}

@end
